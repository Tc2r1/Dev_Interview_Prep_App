package com.dreams.androidquizapp.models;

public interface DomainObject
{
  Integer getId();

  void setId(Integer id);
}
